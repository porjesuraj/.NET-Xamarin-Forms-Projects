﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace InstagramApp
{
	public partial class MyProfilePage : ContentPage
	{
		public MyProfilePage()
		{
			InitializeComponent();
		}
	}
}
